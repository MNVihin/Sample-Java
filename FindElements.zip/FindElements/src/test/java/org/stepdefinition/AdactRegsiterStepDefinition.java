package org.stepdefinition;

import org.pojo.AdactinPOJOLogin;
import org.pojo.AdactinPOJORegister;
import org.testng.Assert;
import org.utilityclass.UtilityClass;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdactRegsiterStepDefinition extends UtilityClass {

	 AdactinPOJOLogin p;
	    AdactinPOJORegister pi;

	    // ---------- BACKGROUND ----------

	    @Given("User launches the browser and hits the url")
	    public void user_launches_the_browser_and_hits_the_url() {
	        launchChromeBrwoser(getDriver());
	        launchUrl("https://adactinhotelapp.com/");
	    }

	    // ---------- LOGIN SCENARIO ----------

	    @When("User enter login credentials")
	    public void user_enter_login_credentials() {
	        p = new AdactinPOJOLogin();
	        customizedXpathMethodWithAttributeSendkeys(
	            p.getUsernameAndPassword(),"name", "username", "Vihin123");
	        customizedXpathMethodWithAttributeSendkeys(
	            p.getUsernameAndPassword(),"name", "password", "Vihin123");
	    }

	    @When("User presses new register here")
	    public void user_presses_new_register_here() {
	        click(p.getRegisterHere());
	    }

	    @Then("User validate the hotel url")
	    public void user_validate_the_hotel_url() {
	        Assert.assertTrue(getDriver().getCurrentUrl().contains("hotel"));
	    }

	    // ---------- REGISTER SCENARIO ----------

	    @When("User enter Register credentials")
	    public void user_enter_register_credentials() {

	        p = new AdactinPOJOLogin();
	        click(p.getRegisterHere());

	        pi = new AdactinPOJORegister();
	        customizedXpathMethodWithAttributeSendkeys(
	            pi.getAllTextBox(),"name", "username", "lkjhtyukgf");
	        customizedXpathMethodWithAttributeSendkeys(
	            pi.getAllTextBox(),"name", "password", "lkjhgf");
	        customizedXpathMethodWithAttributeSendkeys(
	            pi.getAllTextBox(), "name","re_password", "lkjhgf");
	    }

	    @When("User enter the details in Register")
	    public void user_enter_the_details_in_register() {
	    	customizedXpathMethodWithAttributeSendkeys(
	            pi.getAllTextBox(),"name", "full_name", "dfghj");
	    	customizedXpathMethodWithAttributeSendkeys(
	            pi.getAllTextBox(),"name", "email_add", "lkjhgf@gmail.com");
	        click(pi.getClickBox());
	    }

	    @Then("User validate the register url")
	    public void user_validate_the_register_url() {
	        Assert.assertTrue(getDriver().getCurrentUrl().contains("Register"));
	    }
	}


