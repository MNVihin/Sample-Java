package org.utilityclass;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class UtilityClass {
	private static ThreadLocal<WebDriver> tdriver = new ThreadLocal<WebDriver>();

	public static WebDriver getDriver() {
		return tdriver.get();
	}

	public static void launchChromeBrwoser(WebDriver driver) {
		driver=new ChromeDriver();
		
		tdriver.set(driver);
	}
	public static void launchFirefoxBrwoser(WebDriver driver) {
		driver=new FirefoxDriver();
		
		tdriver.set(driver);
	}

	public static void launchEdgeBrwoser(WebDriver driver) {
		driver=new EdgeDriver();
		
		tdriver.set(driver);
	}
	public static void launchSafariBrwoser(WebDriver driver) {
		driver=new SafariDriver();
		
		tdriver.set(driver);
	}
	
    //url
	public static void launchUrl(String url) {
		getDriver().get(url);
	}

	// sendKeys
	public static void sendKeys(WebElement ele, String val) {
		ele.sendKeys(val);
	}

	// Click
	public static void click(WebElement ele) {
		ele.click();
	}
	
	public static void 
	customizedXpathMethodWithAttributeSendkeys(List<WebElement> allElementsTBwithText,String AttributeName, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String attribute = x.getAttribute(AttributeName);
			
			if(attribute.equals(name)) {
				x.sendKeys(value);
			}
		
		}
	}
	
	public static void 
	jsCustomizedXpathMethodWithAttributeSendkeys(List<WebElement> allElementsTBwithText,String AttributeName, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String attribute = x.getAttribute(AttributeName);
			
			if(attribute.equals(name)) {
				javascriptSendKey(x, value);
			}
		
		}
	}
	
	public static void 
	customizedXpathMethodWithAttributeClick(List<WebElement> allElementsTBwithText,String AttributeName, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String attribute = x.getAttribute(AttributeName);
			
			if(attribute.equals(name)) {
				click(x);
			}
		
		}
	}
	
	public static void 
	jsCustomizedXpathMethodWithAttributeClick(List<WebElement> allElementsTBwithText,String AttributeName, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String attribute = x.getAttribute(AttributeName);
			
			if(attribute.equals(name)) {
				javascriptClick(x);
			}
		
		}
	}
	
	public static void 
	customizedXpathMethodWithTextSendkeys(List<WebElement> allElementsTBwithText, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String text = x.getText();
			if(text.equals(name)) {
				x.sendKeys(value);
			}
		
		}
	}
	
	public static void 
	jsCustomizedXpathMethodWithText(List<WebElement> allElementsTBwithText, String name, String value) {
		for(WebElement x : allElementsTBwithText ) { 
			
			String text = x.getText();
			if(text.equals(name)) {
				javascriptSendKey(x, name);
			}
		
		}
	}
	
	public static void printAllText(List<WebElement> allElements) {
		for(WebElement x : allElements) {
			String text = x.getText();
			System.out.println(text);
		}
	}
	

	// Alert
	public static void accptAlert() {
		getDriver().switchTo().alert().accept();

	}

	public static void dismissAlert() {
		getDriver().switchTo().alert().dismiss();

	}

	public static void sendKeysAlert(String val) {
		getDriver().switchTo().alert().sendKeys(val);

	}

	public static void getTextAlert() {
		String text = getDriver().switchTo().alert().getText();
		System.out.println(text);

	}

	// Actions class
	public static void moveTo(WebElement val) {
		Actions act = new Actions(getDriver());
		act.moveToElement(val).perform();

	}

	public static void doubleClick(WebElement val) {
		Actions act = new Actions(getDriver());
		act.doubleClick(val).perform();

	}

	public static void rightClick(WebElement val) {
		Actions act = new Actions(getDriver());
		act.contextClick(val).perform();

	}

	public static void dragAndDrop(WebElement drag, WebElement drop) {
		Actions act = new Actions(getDriver());
		act.dragAndDrop(drag, drop).perform();

	}

	// Robot class
	public static void Enter() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);

	}

	public static void Tab() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);

	}

	// TakeScreenshot
	public static void takeScreenshot(String name) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) getDriver();
		File temp = ts.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\HP\\eclipse-workspace\\Day1\\Sxcrnsholt\\" +name+ ".png");
		FileUtils.copyFile(temp, target);
	}
	
	//JavascriptExecutor
	public static void javascriptSendKey(WebElement ele, String name) {

		JavascriptExecutor js = (JavascriptExecutor) getDriver();

		js.executeScript("arguments[0].setAttribute('value','" + name + "')", ele);

	}

	public static void javascriptClick(WebElement ele) {

		JavascriptExecutor js = (JavascriptExecutor) getDriver();

		js.executeScript("arguments[0].click()", ele);
	}

	public static void tpPage(WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView(True)", ele);

	}

	public static void btPage(WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView(False)", ele);

	}

	// Frames
	public static void switchFrameByEle(WebElement ele) {
		getDriver().switchTo().frame(ele);

	}

	public static void switchFrameByNmae(String nameorId) {
		getDriver().switchTo().frame(nameorId);

	}

	public static void switchFrameByIndex(int index) {
		getDriver().switchTo().frame(index);

	}

	public static void switchFrameToParent() {
		getDriver().switchTo().parentFrame();

	}

	public static void switchToMainFrame() {
		getDriver().switchTo().defaultContent();

	}

	// WindowHandling
	public static void parentWindowId() {
		getDriver().getWindowHandle();
	}

	public static void switchWindow(int index) {
		Set<String> allWindowHandles = getDriver().getWindowHandles();
		List<String> l = new ArrayList<String>();
		getDriver().switchTo().window(l.get(index));

	}

	public static void switchWindowByUrl(String url) {
		getDriver().switchTo().window(url);
	}

	public static void switchWindowByTitle(String Title) {
		getDriver().switchTo().window(Title);
	}

	// DropDown
	public static void selectByIndex(WebElement ele, int index) {
		Select s = new Select(ele);
		s.selectByIndex(index);
	}

	public static void deselectByIndex(WebElement ele, int index) {
		Select s = new Select(ele);
		s.deselectByIndex(index);
	}

	public static void selectByValue(WebElement ele, String value) {
		Select s = new Select(ele);
		s.selectByValue(value);
	}

	public static void deselectByValue(WebElement ele, String value) {
		Select s = new Select(ele);
		s.deselectByValue(value);
	}

	public static void selectByText(WebElement ele, String text) {
		Select s = new Select(ele);
		s.selectByVisibleText(text);

	}

	public static void deselectByText(WebElement ele, String text) {
		Select s = new Select(ele);
		s.deselectByVisibleText(text);

	}

	public static void isMultiple(WebElement ele) {
		Select s = new Select(ele);
		boolean multiple = s.isMultiple();
		System.out.println(multiple);

	}

	public static void getOneOptionByIndex(WebElement ele, int index) {
		Select s = new Select(ele);
		List<WebElement> allSelectedOptions = s.getAllSelectedOptions();
		allSelectedOptions.get(index).getText();

	}

	public static void getAllOptions(WebElement ele) {
		Select s = new Select(ele);
		List<WebElement> allOptions = s.getOptions();
		for (int i = 1; i < allOptions.size(); i++) {
			String text = allOptions.get(i).getText();
			System.out.println(text);
		}
	}

	public static void clickOption(WebElement ele, int i) {
		Select s3 = new Select(ele);
		List<WebElement> ccType = s3.getOptions();
		ccType.get(i).click();
	}

	public static void printAllAttribute(WebElement ele1) {
		Select s = new Select(ele1);
		List<WebElement> ele2 = s.getOptions();

		for (WebElement ele3 : ele2) {
			System.out.println(ele3.getAttribute("value"));

		}
	}

	public static void printOneAttribute(WebElement ele1) {
		Select s = new Select(ele1);
		List<WebElement> ele2 = s.getOptions();
		System.out.println(ele1.getAttribute("value"));

	}

	// Waits
	public static void implicitWait(int seconds) {
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(seconds));

	}

	public static void webDriverWait(int seconds, String xpath) {
		WebDriverWait w = new WebDriverWait(getDriver(), Duration.ofSeconds(seconds));
		w.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	}

	public static void fluentWait(Duration timeout, Duration time, String xpath) {
		FluentWait<WebDriver> f = new FluentWait<WebDriver>(getDriver());
		f.withTimeout(timeout).pollingEvery(time).ignoring(Throwable.class);
		f.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	}

	public static String readFromExcel(String sheet, int row, int cell) throws IOException {
		File f = new File("C:\\Users\\HP\\eclipse-workspace\\Day1\\Excel\\Dummy.xlsx");
		FileInputStream fis = new FileInputStream(f);
		Workbook w = new XSSFWorkbook(fis);
		Sheet sh = w.getSheet(sheet);
		Row r = sh.getRow(row);
		Cell c = r.getCell(cell);

		int type = c.getCellType();
		String value = "";
		if (type == 1) {
			value = c.getStringCellValue();

		} else if (DateUtil.isCellDateFormatted(c)) {
			Date date = c.getDateCellValue();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			value = sdf.format(date);

		} else {
			double dd = c.getNumericCellValue();
			long num = (long) dd;
			value = String.valueOf(num);
		}
		return value;
	}
	
	public static void quit() {
		getDriver().quit();
	}

}