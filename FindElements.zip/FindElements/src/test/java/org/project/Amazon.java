package org.project;

import org.pojo.AmazonPOJO;
import org.utilityclass.UtilityClass;

public class Amazon extends UtilityClass {
	public static void main(String[] args) throws Throwable {
		launchChromeBrwoser(getDriver());
		launchUrl("https://www.amazon.in/");
		Thread.sleep(4000);
		AmazonPOJO p = new AmazonPOJO();
//		sendKeys(p.getSearchBox(), "Iphone");
//		click(p.getSearchElement());
//		
//		printAllText(p.getAllIphone());
	printAllText(p.getAllItems());
	}

}
