package org.project;

import org.pojo.AdactinPOJOLogin;
import org.utilityclass.UtilityClass;

public class Adactin extends UtilityClass{
	public static void main(String[] args) {
		launchChromeBrwoser(getDriver());
		
		launchUrl("https://adactinhotelapp.com/");
		AdactinPOJOLogin p = new AdactinPOJOLogin();
		

		
	}

}
