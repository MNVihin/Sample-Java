package org.project;

import java.awt.AWTException;

import org.pojo.POJOsnapdeal;
import org.utilityclass.UtilityClass;

public class Snapdeal extends UtilityClass {
	public static void main(String[] args) throws Throwable {
		launchChromeBrwoser(getDriver());
		launchUrl("https://www.snapdeal.com/");
		POJOsnapdeal p = new POJOsnapdeal();
//		printAllText(p.getAllText());
		sendKeys(p.getSearchBox(), "kitchen product");
		Enter();
		Thread.sleep(7000);
		printAllText(p.getAllItems());
	}

}
