package org.project;

import java.awt.AWTException;

import org.pojo.FlipkartPOJO;
import org.utilityclass.UtilityClass;

public class Flipkart extends UtilityClass {
	public static void main(String[] args) throws Throwable {
		launchChromeBrwoser(getDriver());
		launchUrl("https://www.flipkart.com/");
		FlipkartPOJO p = new FlipkartPOJO();
//		printAllText(p.getAllItems());
		sendKeys(p.getSearchBox(), "samsung");
		Enter();
		
		Thread.sleep(5000);
		printAllText(p.getAllSamsung());
	}

}
