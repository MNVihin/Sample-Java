package org.project;

import org.pojo.MyntraPOJO;
import org.utilityclass.UtilityClass;

public class Myntra extends UtilityClass {
	public static void main(String[] args) throws Throwable {
		launchChromeBrwoser(getDriver());
		launchUrl("https://www.myntra.com/");
		MyntraPOJO p = new MyntraPOJO();
//		printAllText(p.getAllItems());
		
		sendKeys(p.getSearhBar(), "mens shirts");

}
}
