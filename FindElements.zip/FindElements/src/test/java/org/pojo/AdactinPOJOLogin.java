package org.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class AdactinPOJOLogin extends UtilityClass{
	public AdactinPOJOLogin() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath="//input[@class='login_input']")
	private List<WebElement> usernameAndPassword;
	
	@FindBy(xpath="//a[contains(text(),'New User Register Here')]")
	private WebElement registerHere;

	public WebElement getRegisterHere() {
		return registerHere;
	}




	public List<WebElement> getUsernameAndPassword() {
		return usernameAndPassword;
	}
	
	

}
