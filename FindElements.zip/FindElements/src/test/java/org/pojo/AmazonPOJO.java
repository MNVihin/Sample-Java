package org.pojo;



import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class AmazonPOJO extends UtilityClass {
	public AmazonPOJO() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath="//input[@id='twotabsearchtextbox']")
	private WebElement searchBox;
	
	@FindBy(xpath="//div[@class='nav-search-submit nav-sprite']")
	private WebElement searchElement;
	
	public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getSearchElement() {
		return searchElement;
	}

	

	public List<WebElement> getAllIphone() {
		return allIphone;
	}

	@FindBy(xpath="//a[contains(@class,'a-link-normal s-line-clamp-2')]")
	private List<WebElement> allIphone;

	@FindBy(xpath="//a[@class='nav-a  ']")
	private List<WebElement> allItems;

	public List<WebElement> getAllItems() {
		return allItems;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
