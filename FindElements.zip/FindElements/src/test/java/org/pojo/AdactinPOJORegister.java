package org.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class AdactinPOJORegister extends UtilityClass {
	public AdactinPOJORegister() {
		PageFactory.initElements(getDriver(), this);
	}

	@FindBy(xpath = "//input[@class='reg_input']")
	private List<WebElement> allTextBox;

	public List<WebElement> getAllTextBox() {
		return allTextBox;
	}

	@FindBy(xpath = "//input[@id='tnc_box']")
	private WebElement clickBox;

	public WebElement getClickBox() {
		return clickBox;
	}

	@FindBy(xpath = "//*[@class='reg_input']")                      // common for all reg text box
	private List<WebElement> regTextBox;

	@FindBy(xpath = "//*[contains(@name,'username')]")             //contains username
	private WebElement user;
	
	@FindBy(xpath="//*[contains(@name,'username') and @id='username' and @type='text']")   //and username
	private WebElement usernameReg;
	
	@FindBy(xpath="//*[@name='email_add' or @id='email_add']")     //or email
	private WebElement emailId;
	
	@FindBy(xpath="//input[starts-with(@name,'cap')]")    //starts with
	private WebElement captcha;
	
	@FindBy(xpath="(//input)[@type='text'][position()=4]") //with position
	private WebElement emailBox;
	
	@FindBy(xpath="(//input[@type='text'])[last()]")  //last position
	private WebElement captchBox;
	
	@FindBy(xpath="(//input[@type='text'])[last()-1]")  //before last position
	private WebElement emailBox1;
	
	@FindBy(xpath="//input[@name='password']/self::input")  //self highlighting
	private WebElement passBox;
	
	@FindBy(xpath="//input[@name='password']/parent::td") //using child to parent
	private WebElement passwordBoxx;
	
	@FindBy(xpath="//input[@name='password']/following-sibling::label") //using following sibling 
	private WebElement passwordBoxxx;
	
	@FindBy(xpath="//input[@name='password']/following-sibling::label[@class='reg_error']") //using following sibling xpath
	private WebElement passwordoxxx;
	
	@FindBy(xpath="//*[text()='First name']/ancestor::div[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']") // using ancestor xpath
	private WebElement firstnameReg;

	@FindBy(xpath="//*[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']/descendant::label[@text()='First name']") // using descendant xpath
	private WebElement firstnameRegis;
	
	@FindBy(xpath="//*[@class='x6s0dn4 x78zum5 x1qughib xh8yej3']/child::label[text()='First name']")//parent to child
	private WebElement firname;


}
