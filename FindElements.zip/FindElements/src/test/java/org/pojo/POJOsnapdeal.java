package org.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class POJOsnapdeal extends UtilityClass {
	public POJOsnapdeal() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath="//div[@class='sc-98d0cbe0-3 dXWLks']")
	private List<WebElement> allText;

	public List<WebElement> getAllText() {
		return allText;
	}
	
	@FindBy(xpath="//p[@class='product-title']")
	private List<WebElement> allItems;

	public List<WebElement> getAllItems() {
		return allItems;
	}
	
	@FindBy(xpath="//input[@id='search-box-input']")
	private WebElement searchBox;

	public WebElement getSearchBox() {
		return searchBox;
	}
	
	

}
