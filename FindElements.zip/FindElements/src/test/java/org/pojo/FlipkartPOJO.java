package org.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class FlipkartPOJO extends UtilityClass {
	public FlipkartPOJO() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath="//div[@class='yQdBY2']")
	private List<WebElement> allItems;

	public List<WebElement> getAllItems() {
		return allItems;
	}
	
	@FindBy(xpath="//input[contains(@title,'Search for Products')]")
	private WebElement searchBox;

	public WebElement getSearchBox() {
		return searchBox;
	}
	
	@FindBy(xpath="//div[@class='RG5Slk']")
	private List<WebElement> allSamsung;

	public List<WebElement> getAllSamsung() {
		return allSamsung;
	}

}
