package org.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.utilityclass.UtilityClass;

public class MyntraPOJO extends UtilityClass {
	public MyntraPOJO() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(xpath="//a[@class='desktop-main']")
	private List<WebElement> allItems;

	public List<WebElement> getAllItems() {
		return allItems;
	}
	
	@FindBy(xpath="//input[@class='desktop-searchBar']")
	private WebElement searhBar;

	public WebElement getSearhBar() {
		return searhBar;
	}

}
